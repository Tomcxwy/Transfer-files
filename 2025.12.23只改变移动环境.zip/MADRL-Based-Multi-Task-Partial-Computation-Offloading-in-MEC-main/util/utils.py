import numpy as np
import torch
from config.params import get_params

# -------------------------
# 常用工具函数（日志、可视化、数学工具等）
# -------------------------

# 获取参数配置
params = get_params()

'''动态计算均值和标准差，用于归一化'''

class RunningMeanStd():
    def __init__(self, shape):
        self.n = 0  # 样本数量
        self.mean = np.zeros(shape)  # 当前均值
        self.S = np.zeros(shape)  # 方差累积量
        self.std = np.sqrt(self.S)  # 标准差

    def update(self, x):
        x = np.array(x)
        self.n += 1
        if self.n == 1:  # 第一条样本，直接赋值
            self.mean = x
            self.std = x
        else:  # 增量更新均值和方差（Welford 算法）
            old_mean = self.mean.copy()
            self.mean = old_mean + (x - old_mean) / self.n
            self.S = self.S + (x - old_mean) * (x - self.mean)
            self.std = np.sqrt(self.S / self.n)


'''观测值归一化（obs normalization）'''


class ObsScaling():
    def __init__(self):
        # 运行中的均值/方差（分别对 edge 和 devices）
        self.e_running_ms = RunningMeanStd(1)  # 边缘服务器的观测
        self.d_running_ms = RunningMeanStd(2 * params.device_num)  # 设备的观测（每个设备两个特征）

        # 最大归一化常数（用于约束范围）
        self.max_data_size = params.max_data_size
        self.max_comp_dens = params.max_comp_dens
        # 最大时延约束 = (最大数据大小 × 最大计算密度) / 标准算力
        # max_data_size单位是Mb max_comp_dens单位是G/b(最大任务计算密度)
        self.max_dly_cons = self.max_data_size * pow(10, 6) * self.max_comp_dens \
                            / params.std_comp_freq

    def __call__(self, edge_obs, device_obss, evaluate):
        # 提取边缘观测的第一个元素
        nor_edge_obs = edge_obs[0]
        # 把所有设备的 [obs[0], obs[1]] 拼接在一起
        nor_device_obss = []
        for obs in device_obss:
            nor_device_obss += [obs[0], obs[1]]

        # 训练时更新均值和方差，评估时保持不变
        if not evaluate:
            self.e_running_ms.update(nor_edge_obs)
            self.d_running_ms.update(nor_device_obss)

        # 用 (x - mean)/std 做标准化
        nor_edge_obs = (nor_edge_obs - self.e_running_ms.mean) / \
                       (self.e_running_ms.std + 1e-8)
        nor_device_obss = (nor_device_obss - self.d_running_ms.mean) / \
                          (self.d_running_ms.std + 1e-8)

        # 更新边缘观测
        edge_obs[0] = float(nor_edge_obs)
        # 更新每个设备的观测
        for i in range(params.device_num):
            device_obss[i][0] = float(nor_device_obss[i * 2])  # 标准化的 obs[0]
            device_obss[i][1] = float(nor_device_obss[i * 2 + 1])  # 标准化的 obs[1]
            # 对任务的 [数据大小, 计算密度, 时延约束] 做归一化
            for j in range(params.task_num):
                device_obss[i][2 + j * 3] /= self.max_data_size
                device_obss[i][2 + j * 3 + 1] /= self.max_comp_dens
                device_obss[i][2 + j * 3 + 2] /= self.max_dly_cons


'''奖励归一化（reward scaling）'''


class RewardScaling():
    def __init__(self):
        # 折扣因子 gamma
        self.gamma = params.gamma
        # 折扣累计奖励
        self.R = 0
        # 运行中的均值和方差
        self.r_running_ms = RunningMeanStd(1)

    def __call__(self, reward):
        # 计算折扣累计奖励 R_t = γR_(t-1) + r_t
        self.R = self.gamma * self.R + reward
        # 更新均值和标准差
        self.r_running_ms.update(self.R)
        # 标准化奖励
        reward = float(reward / (self.r_running_ms.std + 1e-8))

        return reward

    # 在一个 episode 结束时重置累计奖励
    def reset(self):
        self.R = 0


'''拼接 edge + device 观测，用于 Value 网络输入'''


def GetValueInputs(edge_obs, device_obss):
    inputs = []
    # 拼接边缘观测
    inputs += edge_obs
    # 拼接所有设备观测
    for i in range(params.device_num):
        inputs += device_obss[i]
    # 转换成 PyTorch 张量，shape = [1, state_dim]
    inputs = torch.tensor(inputs, dtype=torch.float).reshape([1, -1])

    return inputs


'''处理单个 Agent 的观测，用于 Policy 网络输入'''


def GetPolicyInputs(obs):
    # 转换成 PyTorch 张量，shape = [1, obs_dim]
    inputs = torch.tensor(obs, dtype=torch.float).reshape([1, -1])

    return inputs
