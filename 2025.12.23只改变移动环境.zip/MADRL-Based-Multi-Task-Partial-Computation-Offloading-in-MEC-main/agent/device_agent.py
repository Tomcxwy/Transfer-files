import numpy as np
import torch
from torch.distributions import Normal
from network.policy_net import PolicyNet
from util.utils import GetPolicyInputs

# 终端设备智能体的实现，负责 学习和决策 本地任务是本地计算还是卸载到边缘服务器计算
class DeviceAgent():
    def __init__(self, agent_id, params):
        # agent id
        self.agent_id = agent_id

        # policy network
        self.p_net = PolicyNet(params)
        self.action_dim = params.action_dim

        # evaluation mode
        self.eval_mode = params.eval_mode

    def choose_action(self, obs, evaluate):
        if not evaluate or (evaluate and self.eval_mode == "mappo"):
            with torch.no_grad():
                p_inputs = GetPolicyInputs(obs)  # 将观测转换为网络输入
                mean, std = self.p_net(p_inputs)  # 策略网络输出均值和标准差

            if evaluate:  # MAPPO评估模式
                act = mean.squeeze(dim=0).tolist()  # 直接使用均值作为动作
                act_logprob = None  # 评估时不需要对数概率
            else:  # 训练模式
                dist = Normal(mean, std)  # 创建正态分布
                act = dist.sample()  # 从分布中采样动作
                act = torch.clamp(act, 0, 10)  # 将动作限制在[0,10]范围内
                act_logprob = dist.log_prob(act).sum(-1)  # 计算动作的对数概率
                act = act.squeeze(dim=0).tolist()  # 转换为Python列表
                act_logprob = float(act_logprob)  # 转换为浮点数
        elif self.eval_mode == "local_comp":
                # 本地
                act = [0 for i in range(self.action_dim)]
                act_logprob = None
        elif self.eval_mode == "edge_comp":
                act = [10 for i in range(self.action_dim)]
                act_logprob = None
        else:
            act = [np.random.uniform(0, 10) for i in range(self.action_dim)]
            act_logprob = None

        return act, act_logprob

    def load_net(self, path):
        self.p_net.load_state_dict(torch.load(path))

    def update_net(self, params):
        self.p_net.load_state_dict(params)