import copy
import math
import numpy as np


# 终端设备的环境建模（包括任务到达、计算队列）
class Task():
    def __init__(self, data_size, comp_dens):
        '''attributes'''
        # unit: Mb
        self.data_size = data_size
        # unit: Gcycles/bit
        self.comp_dens = comp_dens
        # unit: s
        self.dly_cons = None
        '''local subtask'''
        # computing delay
        self.l_comp_dly = None
        # energy consumption
        self.l_csum_engy = None
        '''offloading subtask'''
        # offloading data-size
        self.offl_dz = None
        # transmission time
        self.trans_time = None
        # computing delay
        self.e_comp_dly = None
        # consumed energy
        self.e_csum_engy = None
        # service expense
        self.comp_expn = None
        '''normalization'''
        self.norm_csum_engy = None
        self.norm_comp_expn = None

    def __str__(self):
        return "data_size: " + str(self.data_size) + \
            "\ncomp_dens: " + str(self.comp_dens) + \
            "\ndly_cons: " + str(self.dly_cons) + \
            "\nl_comp_dly: " + str(self.l_comp_dly) + \
            "\nl_csum_engy: " + str(self.l_csum_engy) + \
            "\noffl_data_size: " + str(self.offl_dz) + \
            "\ntrans_time: " + str(self.trans_time) + \
            "\ne_comp_dly: " + str(self.e_comp_dly) + \
            "\ne_csum_engy: " + str(self.e_csum_engy) + \
            "\ncomp_expn: " + str(self.comp_expn) + \
            "\nnorm_csum_engy: " + str(self.norm_csum_engy) + \
            "\nnorm_comp_expn: " + str(self.norm_comp_expn)


class DeviceEnv():
    def __init__(self, env_id, params):
        # env id
        self.env_id = env_id
        # unit: s
        self.delta = params.delta
        self.task_num = params.task_num
        # unit: Hz
        self.bandwidth = params.total_bandwidth / params.device_num
        # unit: mW  channel_gain 信道增益
        self.trans_power = params.device_trans_powers[env_id]
        self.path_loss = params.device_path_loss[env_id]
        self.channel_gain = None
        # unit: mW  noise_power 噪声功率;spec_dens 噪声功率谱密度(mW/Hz)
        self.noise_power = params.spec_dens * self.bandwidth
        # unit: Mb/s
        self.trans_rate = None
        # unit: Gcycles/s
        self.device_comp_freq = params.device_comp_freqs[env_id]
        # unit: Gcycles/s
        self.std_comp_freq = params.std_comp_freq
        # unit: J/Gcycles
        self.engy_fac = params.device_engy_facs[env_id]
        # unit: KB
        self.data_size_inl = params.data_size_inls[env_id]
        # unit: cycles/bit
        self.comp_dens_inl = params.comp_dens_inls[env_id]
        # unit: $/Gcycles
        self.service_price = params.service_price

        # sample 样本
        self.train_time_slots = params.train_time_slots
        self.eval_time_slots = params.eval_time_slots

        # unit: Gcycles
        self.comp_ql = 0
        self.sched_tasks = []

    def reset(self):
        # reset computation-queue length
        self.comp_ql = 0

        # reset channel gain
        self.channel_gain = self.path_loss * np.random.exponential(1)

        # reset scheduling tasks
        self.sched_tasks.clear()
        for i in range(self.task_num):
            # unit: Mb
            data_size = np.random.uniform(self.data_size_inl[0],
                                          self.data_size_inl[1])
            data_size = data_size * 1024 * 8 * pow(10, -6)
            # unit: Gcycles/bit
            comp_dens = np.random.uniform(self.comp_dens_inl[0],
                                          self.comp_dens_inl[1])
            comp_dens = comp_dens * pow(10, -9)

            task = Task(data_size, comp_dens)

            comp = data_size * pow(10, 6) * comp_dens
            task.dly_cons = comp / self.std_comp_freq
            task.norm_csum_engy = comp * self.engy_fac
            task.norm_comp_expn = comp * self.service_price

            self.sched_tasks.append(task)

        # obs
        obs = self.get_obs()

        return obs

    def get_obs(self):
        comp_ql = copy.copy(self.comp_ql)
        cgnp_rto = self.channel_gain / self.noise_power
        task_msgs = []
        for i in range(self.task_num):
            data_size = self.sched_tasks[i].data_size
            comp_dens = self.sched_tasks[i].comp_dens
            dly_cons = self.sched_tasks[i].dly_cons
            task_msgs += [data_size, comp_dens, dly_cons]
        obs = [comp_ql, cgnp_rto] + task_msgs

        return obs

    def compute(self, act):
        '''offloading'''
        # offloading data-size
        offl_dzs = {}
        for i in range(self.task_num):
            # offloading ratio
            offl_rto = act[i] / 10
            # TODO 公式2 卸载数据大小初始化
            offl_dz = self.sched_tasks[i].data_size * offl_rto
            offl_dzs[i] = offl_dz
        # ascending order
        offl_dzs = sorted(offl_dzs.items(), key=lambda x: x[1])
        # transmission-power ratio
        tspw_rto = act[-1] / 10
        # TODO 传输功率的计算
        trans_power = self.trans_power * tspw_rto
        # unit: Mb/s
        # TODO 公式1 传输速率 (bai ta) trans_rate
        trans_rate = self.bandwidth * math.log(1 + trans_power * self.channel_gain /
                                               self.noise_power, 2) * pow(10, -6)
        # TODO 公式3 传输容量限制
        total_trans_dz = trans_rate * self.delta
        total_offl_dz = 0
        # local computation
        local_comps = {}
        for task_id, offl_dz in offl_dzs:
            # TODO 公式4 卸载数据大小
            offl_dz = min(offl_dz, total_trans_dz)
            total_trans_dz -= offl_dz
            total_offl_dz += offl_dz

            task = self.sched_tasks[task_id]
            task.offl_dz = offl_dz
            # if offl_dz = 0, there is no need to queue
            if task.offl_dz == 0:
                task.trans_time = 0
                task.e_csum_engy = 0
                task.comp_expn = 0
            else:
                # TODO 公式5 传输时间 d0
                task.trans_time = total_offl_dz / trans_rate
                # TODO 公式9 边缘计算能耗
                task.e_csum_engy = trans_power * pow(10, -3) * \
                                   task.offl_dz / trans_rate
                # TODO 公式10 边缘计算费用
                task.comp_expn = task.offl_dz * pow(10, 6) * task.comp_dens * \
                                 self.service_price
            # TODO 公式11中的本地计算负载
            local_comps[task_id] = (task.data_size - task.offl_dz) * pow(10, 6) * \
                                   task.comp_dens

        '''local computing'''
        # ascending order
        local_comps = sorted(local_comps.items(), key=lambda x: x[1])
        # computation-frequency ratio
        total_local_comp = self.comp_ql
        for task_id, local_comp in local_comps:
            task = self.sched_tasks[task_id]
            total_local_comp += local_comp

            # if local_comp = 0, there is no need to queue
            if local_comp == 0:
                task.l_comp_dly = 0
                task.l_csum_engy = 0
            else:
                # TODO 公式11中的本地计算时延
                task.l_comp_dly = total_local_comp / self.device_comp_freq
                # TODO 公式13 本地计算能耗
                task.l_csum_engy = self.engy_fac * local_comp

        # update computation-queue length
        # TODO 公式12 本地计算队列长度
        self.comp_ql = max(0, total_local_comp - self.device_comp_freq * self.delta)

        # update channel gain 更新瞬时信道增益
        # TODO 不确定是不是 5.实验 中第二段的公式
        self.channel_gain = self.path_loss * np.random.exponential(1)

        # update scheduling tasks
        sched_tasks = copy.copy(self.sched_tasks)
        self.sched_tasks.clear()
        for i in range(self.task_num):
            # unit: Mb
            # TODO 上面写的KB 下面怎么变成了Mb 这里进行了换算 将上面的KB换算成Mb
            data_size = np.random.uniform(self.data_size_inl[0],
                                          self.data_size_inl[1])
            data_size = data_size * 1024 * 8 * pow(10, -6)
            # unit: Gcycles/bit
            comp_dens = np.random.uniform(self.comp_dens_inl[0],
                                          self.comp_dens_inl[1])
            comp_dens = comp_dens * pow(10, -9)

            task = Task(data_size, comp_dens)

            # 计算负载
            comp = data_size * pow(10, 6) * comp_dens
            # 任务计算时延
            task.dly_cons = comp / self.std_comp_freq
            # TODO 公式24 标准计算能耗和计算费用
            task.norm_csum_engy = comp * self.engy_fac
            task.norm_comp_expn = comp * self.service_price

            self.sched_tasks.append(task)

        return sched_tasks