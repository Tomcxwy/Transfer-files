import argparse

"""
algorithm params
算法超参数定义文件 5_device
"""


# 保存超参数（如学习率、折扣因子、神经网络结构、带宽/能耗参数等）
def get_params():
    parser = argparse.ArgumentParser(description="algorithm params")

    # 是否进入评估模式（True 表示只评估，不训练）
    parser.add_argument("--evaluate", type=bool, default=False,
                        help="evaluate or train")

    # ===============================
    # 环境参数 Environment
    # ===============================

    # 每个时间片的时长 (秒)
    parser.add_argument("--delta", type=float, default=0.5,
                        help="the duration of each time-slot (s)")

    # 设备数量
    parser.add_argument("--device_num", type=int, default=5,
                        help="the number of devices")

    # 每个时间片到达的任务数量
    parser.add_argument("--task_num", type=int, default=3,
                        help="the number of arrival tasks at each time-slot")

    # 总带宽 (Hz)   10MHz
    parser.add_argument("--total_bandwidth", type=float,
                        default=10 * pow(10, 6),
                        help="the total bandwidth (Hz)")

    # 各设备的发射功率 (mW)  1W = 1000mW
    parser.add_argument("--device_trans_powers", type=list,
                        default=[251, 206, 126, 227, 186],
                        help="the transmission powers of devices (mW)")

    # 各设备的路径损耗
    parser.add_argument("--device_path_loss", type=list,
                        default=[8.0e-11, 8.0e-11, 8.0e-11, 8.0e-11, 8.0e-11],
                        help="the path loss of devices")

    # 噪声功率谱密度 (mW/Hz)
    parser.add_argument("--spec_dens", type=float,
                        default=pow(10, -174 / 10),
                        help="the spectral density of noise power (mW/Hz)")

    # 各设备的计算频率 (Gcycles/s)
    parser.add_argument("--device_comp_freqs", type=list,
                        default=[2.1, 2.5, 2.8, 2.2, 2.4],
                        help="the computation frequencies of devices (Gcycles/s)")

    # 标准计算频率 (Gcycles/s)
    parser.add_argument("--std_comp_freq", type=float, default=2,
                        help="the standard computation frequency (Gcycles/s)")

    # 各设备的能耗因子 (J/Gcycles)
    parser.add_argument("--device_engy_facs", type=list,
                        default=[1, 1, 1, 1, 1],
                        help="the energy factors of devices (J/Gcycles)")

    # 任务数据大小区间 (KB)
    parser.add_argument("--data_size_inls", type=list,
                        default=[[20, 200], [20, 200], [20, 200],
                                 [20, 200], [20, 200]],
                        help="the data-size intervals of tasks (KB)")

    # 任务计算密度区间 (cycles/bit)
    parser.add_argument("--comp_dens_inls", type=list,
                        default=[[200, 2000], [200, 2000], [200, 2000],
                                 [200, 2000], [200, 2000]],
                        help="the computation-density intervals of tasks (cycles/bit)")

    # MEC 服务器计算频率 (Gcycles/s)
    parser.add_argument("--edge_comp_freq", type=float, default=25,
                        help="the computation frequency of MEC server (Gcycles/s)")

    # MEC 服务价格 ($/Gcycles)
    parser.add_argument("--service_price", type=float, default=0.1,
                        help="the service price of MEC server ($/Gcycles)")

    # 任务能耗权重
    parser.add_argument("--energy_weights", type=list,
                        default=[0.8, 0.8, 0.8, 0.8, 0.8],
                        help="the weights of tasks' energy consumption")

    # 任务边缘计算开销权重
    parser.add_argument("--expense_weights", type=list,
                        default=[0.2, 0.2, 0.2, 0.2, 0.2],
                        help="the weights of tasks' edge computation expense")

    # 最大任务数据大小 (Mb)  default =  1.64 Mb
    # 200KB  1KB = 1024 * 8b  1b = pow(10,-6)Mb
    parser.add_argument("--max_data_size", type=float,
                        default=200 * 1024 * 8 * pow(10, -6),
                        help="the max data-size (Mb)")

    # 最大任务计算密度 (Gcycles/bit) default = 2e-6
    parser.add_argument("--max_comp_dens", type=float,
                        default=2000 * pow(10, -9),
                        help="the max computation density (Gcycles/bit)")

    # ===============================
    # 网络参数 Networks
    # ===============================

    # 每个智能体的观测空间维度（例如它能看到的局部环境信息的特征数量），默认值 11
    # 1本地队列 + 1信道增益 + 一个设备3任务特征*3  (每个任务的特征包括数据大小、计算密度、时延约束、)
    parser.add_argument("--obs_dim", type=int, default=11,
                        help="the dimension of agents' observations")

    # 全局状态空间维度（整个环境的特征数量，用于集中训练），默认值 56
    # 注意修改观测空间，设备数*11+1边缘队列
    parser.add_argument("--state_dim", type=int, default=56,
                        help="the dimension of global states")

    # 每个智能体的动作空间维度（可选的动作数量或连续动作的维度），默认值 4
    # 3个任务的卸载比例Q 和 传输功率P
    parser.add_argument("--action_dim", type=int, default=4,
                        help="the dimension of agents' actions")

    # 价值网络隐藏层结构
    parser.add_argument("--v_hid_dims", type=list, default=[400, 400],
                        help="the dimension of value network's hidden layers")

    # 策略网络隐藏层结构
    parser.add_argument("--p_hid_dims", type=list, default=[400, 400],
                        help="the dimension of policy network's hidden layers")

    # 是否使用正交初始化
    parser.add_argument("--use_orthogonal", type=bool, default=True,
                        help="whether to use orthogonal-initialization")

    # ===============================
    # 训练参数 Training
    # ===============================

    parser.add_argument("--train_seed", type=int, default=3456,
                        help="the training random-seed")

    parser.add_argument("--train_episodes", type=int, default=2000,
                        help="the number of training episodes")

    parser.add_argument("--train_time_slots", type=int, default=200,
                        help="the number of training time-slots")

    # 训练频率（每隔多少步训练一次）
    parser.add_argument("--train_freq", type=int, default=2,
                        help="the training frequency")

    # 批量大小
    parser.add_argument("--v_batch_size", type=int, default=400,
                        help="the batch-size of value network")
    parser.add_argument("--p_batch_size", type=int, default=400,
                        help="the batch-size of policy network")

    # 训练轮数（epoch）
    parser.add_argument("--v_epochs", type=int, default=4,
                        help="the number of epoches of value network")
    parser.add_argument("--p_epochs", type=int, default=4,
                        help="the number of epoches of policy network")

    # 奖励折扣因子
    parser.add_argument("--gamma", type=float, default=0.99,
                        help="the discount factor of reward")

    # GAE 参数
    parser.add_argument("--lamda", type=float, default=0.95,
                        help="the param about GAE")

    # 学习率
    parser.add_argument("--v_lr", type=float, default=4e-4,
                        help="the learning-rate of value network")
    parser.add_argument("--p_lr", type=float, default=4e-4,
                        help="the learning-rate of policy network")

    # Adam 优化器的 epsilon
    parser.add_argument("--adam_eps", type=float, default=1e-5,
                        help="the param about Adam optimizer")

    # 是否使用学习率衰减
    parser.add_argument("--use_lr_decay", type=bool, default=True,
                        help="whether to use learning-rate decay")

    # 最小学习率
    parser.add_argument("--min_v_lr", type=float, default=1e-4,
                        help="the minimal learning-rate of value network")
    parser.add_argument("--min_p_lr", type=float, default=1e-4,
                        help="the minimal learning-rate of policy network")

    # 学习率衰减因子
    parser.add_argument("--decay_fac", type=float, default=0.999,
                        help="the param about learning-rate decay")

    # 观测值缩放 / 奖励缩放
    parser.add_argument("--use_obs_scaling", type=bool, default=True,
                        help="whether to use observation scaling")
    parser.add_argument("--load_scales", type=bool, default=False,
                        help="whether to load observation scaling params")
    parser.add_argument("--use_reward_scaling", type=bool, default=True,
                        help="whether to use reward scaling")

    # 梯度裁剪
    parser.add_argument("--use_grad_clip", type=bool, default=True,
                        help="whether to use gradient clip")
    parser.add_argument("--v_grad_clip", type=float, default=2,
                        help="the param about value network's gradient clip")
    parser.add_argument("--p_grad_clip", type=float, default=2,
                        help="the param about policy network's gradient clip")

    # PPO 裁剪参数
    parser.add_argument("--p_clip", type=float, default=0.1,
                        help="the param about ppo clip")

    # 策略熵正则化系数
    parser.add_argument("--enty_coef", type=float, default=0.01,
                        help="the coefficient about policy's entropy")

    # 网络保存/可视化频率
    parser.add_argument("--save_freq", type=int, default=500,
                        help="the save frequency of networks")
    parser.add_argument("--visu_freq", type=int, default=50,
                        help="the visualization frequency")

    # 是否加载已有权重
    parser.add_argument("--load_weights", type=bool, default=False,
                        help="whether to load network params")

    # 模型和结果的保存目录
    parser.add_argument("--weights_dir", type=str, default="weight/",
                        help="the dir for saving network params")
    parser.add_argument("--results_dir", type=str, default="result/",
                        help="the dir for saving training results")

    # ===============================
    # 评估参数 Evaluation
    # ===============================

    # 评估时的随机种子
    parser.add_argument("--eval_seed", type=int, default=2345,
                        help="random seed")

    # 评估模式（如 mappo）
    parser.add_argument("--eval_mode", type=str, default="mappo",
                        help="evaluation mode")

    # 评估的回合数和时隙数
    parser.add_argument("--eval_episodes", type=int, default=25,
                        help="the number of sample-episodes for evaluation")
    parser.add_argument("--eval_time_slots", type=int, default=200,
                        help="the number of time-slots for evaluation")

    # 解析参数并返回
    params = parser.parse_args()

    return params
