import pickle
import matplotlib.pyplot as plt
import numpy as np
import os

# 1. 基础配置
plt.rcParams['font.sans-serif'] = ['SimHei']  # 支持中文
plt.rcParams['axes.unicode_minus'] = False
RESULTS_DIR = "result/"  # 你的数据存放目录
EPISODE_TAG = "2000"  # 想要画哪一个阶段的文件（1000, 2000, 3000, 4000）

# 2. 定义映射关系：文件名关键词 -> (纵坐标标签, 图表标题, 是否为能耗)
plot_config = {
    "joint_rewards": ("Joint Reward", "联合奖励", False),
    "device_rewards": ("Device Reward", "设备个体奖励", False),
    "joint_costs": ("Joint Cost", "联合成本", False),
    "device_costs": ("Device Cost", "设备个体成本", False),
    "edge_comp_qls": ("Queue Length (Gcycles)", "边缘服务器队列长度", False),
    "device_comp_qls": ("Queue Length (Gcycles)", "本地设备队列长度", False),
    "device_comp_dlys": ("Delay (s)", "任务计算延迟", False),
    "device_csum_engys": ("Energy-Consumption (mJ)", "任务能耗", True),
    "device_comp_expns": ("Expense", "计算开销", False),
    "device_overtime_nums": ("Overtime-Number", "设备任务超时次数", False)
}


def plot_all_results():
    # 检查文件夹是否存在
    if not os.path.exists(RESULTS_DIR):
        print(f"错误：找不到目录 {RESULTS_DIR}")
        return

    # 遍历配置进行绘图
    for key, (ylabel, title, is_energy) in plot_config.items():
        file_name = f"{key}_{EPISODE_TAG}.pkl"
        file_path = os.path.join(RESULTS_DIR, file_name)

        if os.path.exists(file_path):
            with open(file_path, "rb") as f:
                data = pickle.load(f)

            y = np.array(data)

            # 特殊处理：能耗单位转换
            if is_energy:
                y = y * 1000

            x = np.arange(len(y))

            plt.figure(figsize=(12, 8))

            # 判断是单条曲线还是多条曲线
            if len(y.shape) > 1:
                device_num = y.shape[1]
                for i in range(device_num):
                    plt.plot(x, y[:, i], marker=".", markersize=2, linewidth=2.5, label=f"Device {i}")
                plt.legend(
                    loc='upper right',
                    ncol=1,
                    fontsize=23,  # 调整字体大小，整体尺寸随之改变
                    handlelength=1.5,  # 缩短图例线条的长度，减小宽度
                    handletextpad=0.6,  # 缩短线条与文字之间的距离
                    labelspacing=0.8,  # 调整行与行之间的垂直间距
                    borderpad=0.5,  # 调整图例边框内部的留白
                    # edgecolor='black',  # 设置边框颜色
                    # framealpha=0.8  # 设置背景透明度
                )
            else:
                plt.plot(x, y, marker=".", markersize=2, linewidth=3)

            plt.grid(True)
            plt.xlabel("Episodes", fontsize=18)
            plt.ylabel(ylabel, fontsize=18)
            plt.tick_params(axis='both', labelsize=18)

            # plt.title(f"{title} ({EPISODE_TAG} Episodes)", fontsize=16)

            # 如果你想直接保存图表，取消下面这一行的注释
            # plt.savefig(f"{key}_{EPISODE_TAG}.png")

            plt.show()
        else:
            print(f"跳过：未找到文件 {file_name}")


if __name__ == "__main__":
    plot_all_results()